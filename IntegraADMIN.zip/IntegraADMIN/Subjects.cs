﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IntegraADMIN
{
    public partial class Subjects : Form
    {
        public Subjects()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //subject name
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //subject code
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //teacher
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            //units
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            //room
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //clear
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //add
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //section
        }

        private void textBox5_TextChanged_1(object sender, EventArgs e)
        {
            //description

        }
    }
}
