﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IntegraADMIN
{
    public partial class IT201WMT : Form
    {
        public IT201WMT()
        {
            InitializeComponent();
        }

        private void IT201WMT_Load(object sender, EventArgs e)
        {

        }
    }
}
