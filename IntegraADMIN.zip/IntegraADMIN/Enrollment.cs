﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IntegraADMIN
{
    public partial class Enrollment : Form
    {
        public Enrollment()
        {
            InitializeComponent();
        }

        private void Enrollment_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //student id
        }

        private void StudentName_TextChanged(object sender, EventArgs e)
        {
            //student name
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            //course
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //subjects

        }

        private void studentype_SelectedIndexChanged(object sender, EventArgs e)
        {
            //semester
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //year level
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //clear
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //add
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //delete
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //update
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //course
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            //year
        }
    }
}
