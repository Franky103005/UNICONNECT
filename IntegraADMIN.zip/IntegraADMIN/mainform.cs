﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IntegraADMIN
{
    public partial class mainform : Form
    {
        public mainform()
        {
            InitializeComponent();
        }

        // Helper method to close any open child forms before launching a new one
        // This stops your screens from stacking up chaotically underneath each other
        private void CloseAllChildForms()
        {
            foreach (Form child in this.MdiChildren)
            {
                child.Close();
            }
        }

        private void layoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Leave blank or use for general layout settings if needed
        }

        private void cascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void horizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void verticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void enrollmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllChildForms(); // Clears previous form

            Enrollment enrollmentForm = new Enrollment();
            enrollmentForm.MdiParent = this; // Sets this mainform as the wrapper shell
            enrollmentForm.FormBorderStyle = FormBorderStyle.None; // Removes floating borders
            enrollmentForm.Dock = DockStyle.Fill; // Makes it fit the whole empty workspace
            enrollmentForm.Show(); // Officially displays it!
        }

        private void studentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllChildForms();

            Student studentForm = new Student();
            studentForm.MdiParent = this;
            studentForm.FormBorderStyle = FormBorderStyle.None;
            studentForm.Dock = DockStyle.Fill;
            studentForm.Show();
        }

        private void teachersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllChildForms();

            Teacher teacherForm = new Teacher();
            teacherForm.MdiParent = this;
            teacherForm.FormBorderStyle = FormBorderStyle.None;
            teacherForm.Dock = DockStyle.Fill;
            teacherForm.Show();
        }

        private void subjectsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseAllChildForms();

            Subjects subjectForm = new Subjects();
            subjectForm.MdiParent = this;
            subjectForm.FormBorderStyle = FormBorderStyle.None;
            subjectForm.Dock = DockStyle.Fill;
            subjectForm.Show();
        }

        private void mainform_Load(object sender, EventArgs e)
        {
            // Optional: If you created a DashboardSummary page, you can make it 
            // open automatically right here as soon as the main program runs!
        }

        private void iT201WMTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IT201WMT    IT201WMTForm = new IT201WMT();
            IT201WMTForm.MdiParent = this;
            IT201WMTForm.FormBorderStyle = FormBorderStyle.None;
            IT201WMTForm.Dock = DockStyle.Fill;
            IT201WMTForm.Show();
        }

        private void iT202WMTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IT202WMT IT202WMTForm = new IT202WMT();
            IT202WMTForm.MdiParent = this;
            IT202WMTForm.FormBorderStyle = FormBorderStyle.None;
            IT202WMTForm.Dock = DockStyle.Fill;
            IT202WMTForm.Show();
        }

        private void teachersToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            teacherccs teachercssForm = new teacherccs();
            teachercssForm.MdiParent = this;
            teachercssForm.FormBorderStyle = FormBorderStyle.None;
            teachercssForm.Dock = DockStyle.Fill;
            teachercssForm.Show();
        }
    }
}