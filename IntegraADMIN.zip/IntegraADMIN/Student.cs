﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IntegraADMIN
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }

        private void Student_Load(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //clear
        }


        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            //student name
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //student id
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            //department
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            //course
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //year level
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //student type
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //email
        }

        private void label10_Click(object sender, EventArgs e)
        {
            //passwords
        }
    }
}
