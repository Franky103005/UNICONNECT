﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IntegraADMIN
{
    public partial class Teacher : Form
    {
        public Teacher()
        {
            InitializeComponent();
        }

        private void Teacher_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //teacher name
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //teacher id
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //department
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //room assignment
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            //email
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            //passwords
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            //employment status
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            //date hired
        }

        private void comboBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            //position
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
